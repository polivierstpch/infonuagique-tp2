﻿namespace AutoRapide.Vehicules.API;

public struct CustomLogEvents
{
    public const int Lecture = 100;
    public const int Creation = 101;
    public const int Modification = 102;
    public const int Suppression = 103;
}