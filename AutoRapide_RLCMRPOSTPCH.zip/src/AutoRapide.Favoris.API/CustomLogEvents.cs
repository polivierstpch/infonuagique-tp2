﻿namespace AutoRapide.Favoris.API
{
    public class CustomLogEvents
    {
        public const int Lecture = 100;
        public const int Creation = 101;
        public const int Modication = 102;
        public const int Suppression = 103;
    }

}
