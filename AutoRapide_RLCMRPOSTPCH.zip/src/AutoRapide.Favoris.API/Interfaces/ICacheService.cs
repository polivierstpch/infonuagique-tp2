﻿namespace AutoRapide.Favoris.API.Interfaces
{
    public interface ICacheService
    {
        void SetValuesCacheFavoris(List<int> data, string ip);
    }
}
