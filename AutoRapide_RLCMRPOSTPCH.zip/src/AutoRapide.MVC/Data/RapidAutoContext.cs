﻿namespace AutoRapide.MVC.Data
{
    public class RapidAutoContext
    {
    }
}
