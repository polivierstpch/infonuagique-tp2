﻿namespace AutoRapide.MVC.Models
{
    public class Commandes
    {
    }
}
